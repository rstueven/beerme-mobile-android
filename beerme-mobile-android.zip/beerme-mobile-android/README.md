beerme-mobile-android
=====================

Beer Me! mobile: The most complete source of brewery information worldwide is now available on your mobile device. Find nearby breweries. Look up information on beers. See the ratings from beerme.com and write your own. Plan your next beer vacation.

Version 2.4.3
==============
Fixes to accommodate Android 6.
