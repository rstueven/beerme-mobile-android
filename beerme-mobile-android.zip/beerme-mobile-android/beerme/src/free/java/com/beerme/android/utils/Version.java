package com.beerme.android.utils;

/**
 * Free version.
 * Created by rstueven on 5/25/15.
 */
public class Version {
    public static final boolean FREE = true;

    private Version(){}
}