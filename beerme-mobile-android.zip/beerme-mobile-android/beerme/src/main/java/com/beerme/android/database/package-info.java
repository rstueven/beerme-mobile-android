/**
 * 
 */
/**
 * @author rstueven
 *
 */
package com.beerme.android.database;