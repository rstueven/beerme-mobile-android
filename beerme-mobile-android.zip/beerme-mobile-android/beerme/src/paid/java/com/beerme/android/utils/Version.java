package com.beerme.android.utils;

/**
 * Paid version.
 * Created by rstueven on 5/25/15.
 */
public class Version {
    public static final boolean FREE = false;

    private Version(){}
}